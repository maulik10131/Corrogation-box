-- Corrugation Box PMS Database Schema

-- Users & Authentication
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'manager', 'operator', 'staff') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Inventory Management
CREATE TABLE raw_materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    type ENUM('paper', 'adhesive', 'ink', 'other') NOT NULL,
    gsm INT NULL,  -- For paper
    quantity DECIMAL(10,2) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    min_stock_level DECIMAL(10,2),
    price_per_unit DECIMAL(10,2),
    supplier_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Box Specifications & Calculations
CREATE TABLE box_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    
    -- Box Dimensions (in mm)
    length DECIMAL(10,2) NOT NULL,
    width DECIMAL(10,2) NOT NULL,
    height DECIMAL(10,2) NOT NULL,
    
    -- Flute Type
    flute_type ENUM('A', 'B', 'C', 'E', 'F', 'BC', 'AB') NOT NULL,
    
    -- Ply Configuration
    ply_count INT NOT NULL,  -- 3, 5, 7 ply
    
    -- Paper GSM for each layer
    liner_gsm INT NOT NULL,
    fluting_gsm INT NOT NULL,
    
    -- Calculated Values
    deckle_size DECIMAL(10,2),
    cutting_size DECIMAL(10,2),
    sheet_area DECIMAL(10,4),
    box_weight DECIMAL(10,3),
    
    -- Pricing
    paper_cost DECIMAL(10,2),
    conversion_cost DECIMAL(10,2),
    total_cost DECIMAL(10,2),
    selling_price DECIMAL(10,2),
    
    quantity INT NOT NULL,
    status ENUM('pending', 'in_production', 'completed', 'delivered') DEFAULT 'pending',
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivery_date DATE
);

-- Production Tracking
CREATE TABLE production_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    machine VARCHAR(100),
    process ENUM('corrugation', 'pasting', 'slitting', 'creasing', 'printing', 'die_cutting', 'stitching', 'packing'),
    quantity_produced INT,
    wastage INT,
    operator_id INT,
    shift ENUM('morning', 'evening', 'night'),
    start_time DATETIME,
    end_time DATETIME,
    notes TEXT,
    FOREIGN KEY (order_id) REFERENCES box_orders(id),
    FOREIGN KEY (operator_id) REFERENCES users(id)
);

-- Attendance
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    check_in TIME,
    check_out TIME,
    status ENUM('present', 'absent', 'half_day', 'leave') DEFAULT 'present',
    overtime_hours DECIMAL(4,2) DEFAULT 0,
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE KEY unique_attendance (user_id, date)
);

-- Stock Transactions
CREATE TABLE stock_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    material_id INT,
    transaction_type ENUM('in', 'out') NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    reference_type VARCHAR(50),  -- 'purchase', 'production', 'adjustment'
    reference_id INT,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (material_id) REFERENCES raw_materials(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);